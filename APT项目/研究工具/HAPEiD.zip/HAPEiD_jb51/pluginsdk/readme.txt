The Sample sources were provided by

PowerBASIC, Mark0
C++ , snaker
Delphi, _pusher_
MASM, diablo2oo2