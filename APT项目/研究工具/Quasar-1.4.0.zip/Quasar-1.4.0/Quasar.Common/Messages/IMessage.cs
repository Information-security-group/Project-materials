﻿namespace Quasar.Common.Messages
{
    public interface IMessage
    {
    }
}
