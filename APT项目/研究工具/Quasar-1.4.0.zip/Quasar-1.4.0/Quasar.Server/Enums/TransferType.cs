﻿namespace Quasar.Server.Enums
{
    public enum TransferType
    {
        Upload,
        Download
    }
}
